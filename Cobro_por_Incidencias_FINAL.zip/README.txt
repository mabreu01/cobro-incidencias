Subir index.html al repositorio GitHub mabreu01/cobro-incidencias.
Luego activar GitHub Pages desde Settings > Pages > Deploy from a branch > main > /(root).
